<template>
  <div>
    <v-row>
      <v-col cols="12">
        <div class="display-2 mt-12 mb-4">About Garments Maker Limited</div>
        <p>
          Garments Maker Ltd. is a garment exporter and sourcing company created
          to match potential buyers with ideal suppliers. We aim to find our
          clients the perfect suppliers who will not only provide pristine
          quality garments within a competitive price range.
        </p>
        <p>
          While doing this, we also make sure the raw materials and labor are
          sourced ethically. At Garments maker, we conduct extensive research to
          filter out only the best suppliers who meet all the critical criteria
          and certifications which are demanded by the clients. Even though our
          main focus is on sourcing specialized or critical products for our
          clients but we are also ready to support startup businesses or those
          who wish to order in smaller quantities. We incorporated our business
          in 2018 and within this relatively short period of time we were able
          to deliver our services to renowned brands from Russia, UK, US and
          other European countries.
        </p>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" sm="6">
        <v-card outlined class="card">
          <v-card-title>
            <v-icon class="icon" color="secondary">mdi-bullseye-arrow</v-icon>
          </v-card-title>
          <v-card-text>
            We are putting purpose at the core of what we do at Li & Fung to
            make a difference along the supply chain. We know we cannot do this
            alone and are using our convening power to enable collaboration and
            partnerships to make positive impacts that are scalable and
            sustainable.
            <div class="card-title mt-4">OUR PURPOSE</div>
          </v-card-text>
        </v-card>
      </v-col>
      <v-col cols="12" sm="6">
        <v-card outlined class="card">
          <v-card-title>
            <v-icon class="icon earth" color="secondary">mdi-earth</v-icon>
          </v-card-title>
          <v-card-text>
            We operate one of the most extensive global supply chain networks in
            the world with some 15,000 people in more than 230 locations across
            40 different markets. Leveraging our convening power, we bring
            together diverse players in the supply chain to change for the
            benefit of our industry.
            <div class="card-title mt-4">OUR REACH</div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
.display-2,
.title {
  font-family: 'Poppins', sans-serif !important;
  color: '#3e3e3e';
}
.card {
  border-radius: 12px;
  .earth {
    animation: circle 2s linear infinite;
  }

  .card-title {
    font-size: 1.5em;
    font-weight: 600;
  }

  @keyframes circle {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }

  &:hover {
    .card-title {
      color: #f59e0b !important;
    }
  }
}
.icon {
  font-size: 2.5em;
}
.title {
  font-weight: 600;
}
</style>
