<template>
  <div>
    <div class="display-2 mt-12 mb-6">Our Mission</div>
    <p >
      Our mission is to become the leading exporter & sourcing company in the
      industry by providing excellent service to our clients at a competitive
      price point.
    </p>

    <p>
      We are constantly putting our best efforts to source trendy & superior
      quality garments material from ethical and sustainable suppliers. We also
      want to share our success by giving back to the society. This will be
      achieved through providing fare wages to the workers, introducing a green
      production facility and contributing to the education of underprivileged
      children.
    </p>
    <p>
      By accomplishing these series of actions, we want to establish Garments
      Maker as a brand which will be represented by its dedication towards
      sustainability, customer satisfaction and value creation.
    </p>
  </div>
</template>

<style lang="scss" scoped>
.display-2 {
  font-family: 'Poppins', sans-serif !important;
}
</style>
